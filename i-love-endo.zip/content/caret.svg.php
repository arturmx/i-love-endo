<svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M13.9976 0.0012207L9.3233 4.67551L4.67428 0.0012207L0 4.67551L9.3233 13.9988L18.6719 4.67551L13.9976 0.0012207Z" fill="#E53020"/>
</svg>