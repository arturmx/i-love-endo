<section class="page--default">
    <h1><?php the_title(); ?></h1>
    <?php 
        require (TEMPLATEPATH . '/content/pages/program/section_1.php');
        require (TEMPLATEPATH . '/content/pages/program/section_2.php');
    ?>
</section>