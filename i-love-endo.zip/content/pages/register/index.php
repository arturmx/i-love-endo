<section class="page--default">
    <h1><?php the_title(); ?></h1>
    <?php 
        require (TEMPLATEPATH . '/content/pages/register/packets.php');
        // require (TEMPLATEPATH . '/content/pages/hotel/sections.php');
    ?>
</section>