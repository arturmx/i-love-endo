<div class="contest--banner">
    <div class="container">
        <div class="body">
            <?php the_content(); ?>
        </div>
    </div>
</div>