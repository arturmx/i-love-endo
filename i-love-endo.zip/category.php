<?php get_header('type2'); // header ?>

<main>
    <?php require (TEMPLATEPATH . '/content/pages/post/list.php'); ?>
</main>

<?php get_footer(); // footer