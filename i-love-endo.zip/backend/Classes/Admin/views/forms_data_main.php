<div class="wrap">
    
    <h1><?php echo get_admin_page_title(); ?></h1>
    
    <br/>
    
    <a href="<?php echo admin_url('admin.php?page=form-data-contacts'); ?>" class="button button-primary">Dane z formularzu kontaktowego</a>
    
    <br/>
    <br/>
    
    <a href="<?php echo admin_url('admin.php?page=form-data-applications'); ?>" class="button button-primary">Dane z formularzy zgłoszeniowych</a>
    
</div>